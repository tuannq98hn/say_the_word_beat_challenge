package com.example.flutter_ads_native_example

import io.flutter.embedding.android.FlutterActivity

class MainActivity : FlutterActivity()
